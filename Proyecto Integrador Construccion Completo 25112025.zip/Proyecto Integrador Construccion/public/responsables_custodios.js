// public/responsables_custodios.js
const API = '/api/responsables-custodios';
const tbody = document.getElementById('tbody');
const btnNuevo = document.getElementById('btnNuevo');
const modal = new bootstrap.Modal(document.getElementById('modal'));
const $ = (id) => document.getElementById(id);

// Verificación de roles (Admin o Administrativo)
const isAdmin = window.CURRENT_USER_ROLE === 'admin';
const isAdministrativo = window.CURRENT_USER_ROLE === 'administrativo';


// HELPERS 

// Muestra notificaciones tipo "Toast" en la esquina
function showToast(message, type = 'success') {
  const container = document.getElementById('toastContainer');
  const bg = type === 'success' ? 'bg-success' : type === 'error' ? 'bg-danger' : 'bg-info';
  const el = document.createElement('div');
  el.className = `toast align-items-center text-white ${bg} border-0`;
  el.role = 'alert'; el.ariaLive = 'assertive'; el.ariaAtomic = 'true';
  el.innerHTML = `<div class="d-flex"><div class="toast-body">${message}</div>
    <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button></div>`;
  container.appendChild(el);
  const t = new bootstrap.Toast(el, { delay: 2800 }); t.show();
  el.addEventListener('hidden.bs.toast', () => el.remove());
}

// Función genérica para peticiones Fetch
async function fetchJSON(url, opts) {
  const r = await fetch(url, opts);
  if (!r.ok) throw new Error(await r.text());
  return r.json();
}
// 3. LISTADO Y FILTRAR
async function listar() {
  // A. Obtener datos de la API
  let data = [];
  try {
    data = await fetchJSON(API);
  } catch (error) {
    console.error(error);
  }

  tbody.innerHTML = "";
  if (!Array.isArray(data)) data = [];

  // B. Leer filtros del HTML
  const fCodigo = $("fCodigo")?.value.trim().toLowerCase();   
  const fPersona = $("fPersona")?.value.trim().toLowerCase(); 

  // C. Filtrar datos en memoria
  const filteredData = data.filter(r => {
    const matchCodigo = !fCodigo || (r.id_area || '').toLowerCase().includes(fCodigo);
    const matchNombre = !fPersona || (r.nombre_area || '').toLowerCase().includes(fPersona);
    return matchCodigo && matchNombre;
  });

  // D. Renderizar tabla
  if (!filteredData.length) {
    tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted py-4">Sin resultados</td></tr>';
    return;
  }

  filteredData.forEach(r => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${r.id}</td>
      <td>${r.id_area || ''}</td>
      <td>${r.nombre_area || ''}</td>
      <td>${r.createdAt || ''}</td>
      <td>${r.updatedAt || ''}</td>
      <td>
        ${
          (isAdmin || isAdministrativo)
            ? `
              <button class="btn btn-sm btn-warning me-2"
                      data-act="edit" data-id="${r.id}">Editar</button>
              <button class="btn btn-sm btn-danger"
                      data-act="del" data-id="${r.id}">Eliminar</button>
            `
            : `<span class="text-muted small">Solo lectura</span>`
        }
      </td>
    `;
    tbody.appendChild(tr);
  });
}

//Filtros

// Botón Filtrar
document.getElementById("btnFiltrar")?.addEventListener("click", () => {
  listar().catch(() => showToast("Error al filtrar", "error"));
});

// Botón Limpiar
document.getElementById("btnLimpiar")?.addEventListener("click", () => {
  if($("fCodigo")) $("fCodigo").value = "";
  if($("fPersona")) $("fPersona").value = "";
  listar().catch(() => showToast("Error", "error"));
});

// NUEVO (Abrir Modal)
btnNuevo?.addEventListener('click', () => {
  $('title').textContent = 'Nuevo responsable/custodio';
  // Limpiar campos
  $('id').value = '';
  $('id_area').value = '';
  $('nombre_area').value = '';
  modal.show();
});

// ACCIONES EN TABLA (Editar / Eliminar)
tbody.addEventListener('click', async (e) => {
  // Permisos
  if (!(isAdmin || isAdministrativo)) return;

  const btn = e.target.closest('button');
  if (!btn) return;
  const { act, id } = btn.dataset;

  // Acción EDITAR
  if (act === 'edit') {
    try {
        // Traemos todo para buscar el item especifico (Estrategia frontend)
        const items = await fetchJSON(API);
        const r = items.find(x => x.id == id);
        
        if (!r) return showToast('No encontrado', 'error');
        
        // Llenar modal
        $('title').textContent = `Editar responsable/custodio #${id}`;
        $('id').value = id;
        $('id_area').value = r.id_area;
        $('nombre_area').value = r.nombre_area;
        modal.show();
    } catch(err) {
        showToast('Error al cargar datos', 'error');
    }

  // Acción ELIMINAR
  } else if (act === 'del') {
    if (!confirm('¿Eliminar responsable/custodio?')) return;
    try {
      await fetchJSON(`${API}/${id}`, { method: 'DELETE' });
      await listar(); 
      showToast('Eliminado', 'info');
    } catch (e) {
      showToast('No se pudo eliminar (quizá tiene equipos asociados)', 'error');
    }
  }
});

// GUARDAR (Crear / Editar)
document.getElementById('form')?.addEventListener('submit', async (e) => {
  e.preventDefault();
  
  // Permisos
  if (!(isAdmin || isAdministrativo)) {
    showToast('No tiene permisos para modificar responsables/custodios', 'error');
    return;
  }

  const payload = {
    id_area: $('id_area').value.trim(),
    nombre_area: $('nombre_area').value.trim()
  };
  
  const id = $('id').value;
  
  try {
    if (id) {
      // PUT (Editar)
      await fetchJSON(`${API}/${id}`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
    } else {
      // POST (Crear)
      await fetchJSON(API, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
    }
    modal.hide();
    await listar();
    showToast(id ? 'Actualizado' : 'Creado');
  } catch (e) {
    showToast('Error al guardar', 'error');
  }
});

// INICIALIZACIÓN
(async function init(){
  try {
    await listar();
  } catch(e) {
    console.error(e);
    showToast('Error al listar', 'error');
  }
})();